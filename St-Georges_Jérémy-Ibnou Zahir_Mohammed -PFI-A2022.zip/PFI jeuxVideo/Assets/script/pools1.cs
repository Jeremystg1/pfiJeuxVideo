using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class pools1 : MonoBehaviour
{
    private Stack<GameObject> pools = new Stack<GameObject>();
    [SerializeField] GameObject instanceToPool;
    public int poolSize = 200;

    public GameObject Take()
    {
        if (pools.Count <= 0)
        {
            Fill(20);
            //Debug.Log("refill rapide");
        }

        GameObject obj = pools.Pop();
        return obj;
    }
    public void ReturnElement(GameObject obj)
    {
        obj.SetActive(false);
        obj.gameObject.SetActive(false);
        pools.Push(obj);
        //print(pools.Count);
    }
    public void Fill(int? x)
    {
        if (!x.HasValue) { x = poolSize; }
        for (int i = 0; i < x; i++)
        {
            GameObject obj = Instantiate(instanceToPool);
            obj.SetActive(false);
            pools.Push(obj);
        }
    }

    void Start() { Fill(null); }
    void Update() { }
}
