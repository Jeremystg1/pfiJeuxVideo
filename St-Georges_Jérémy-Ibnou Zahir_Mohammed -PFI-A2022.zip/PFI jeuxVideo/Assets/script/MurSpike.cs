using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MurSpike : MonoBehaviour
{
    private AudioSource hitDamageSound;
    public float speed = 1;
    // Update is called once per frame
    void Awake()
    {

        partage.mur = this;
        hitDamageSound = this.GetComponent<AudioSource>();
        partage.hitDamageSound = hitDamageSound;
    }

    void Update()
    {
        if (!partage.player.inputDisable)
        {
            Vector3 v = new(speed * Time.deltaTime, 0, 0);
            this.transform.Translate(v);
        }
    }
}
