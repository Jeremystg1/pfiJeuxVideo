using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class BulletScript : MonoBehaviour
{
    public int Orientation = 1;
    private float Speed = 3f;
    private float elapsedTime = 0;
    private float delayBeforeDelete = 5;
    [SerializeField]public GameObject spritefeu;
    private AudioSource audio;

    // Start is called before the first frame update
    void Start()
    {
        audio = GetComponent<AudioSource>();
        audio.Play();
        if (Orientation == 0)
            Orientation = 1;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 v3 = new(Speed*Time.deltaTime * Orientation, 0);
        transform.Translate(v3);
        spritefeu.transform.Rotate(new Vector3(0, 0, 1));

        elapsedTime += Time.deltaTime;
        if (elapsedTime >= delayBeforeDelete)
        {
            elapsedTime = 0;
            partage.bulletPool.ReturnElement(this.gameObject);

        }
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "ennemie")
        {
            Debug.Log("ennemie");
            Destroy(collision.gameObject);
            partage.bulletPool.ReturnElement(this.gameObject);
        }
    }
}
