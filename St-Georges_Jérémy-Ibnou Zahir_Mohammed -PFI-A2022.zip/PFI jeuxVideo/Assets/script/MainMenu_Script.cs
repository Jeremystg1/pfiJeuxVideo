using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using static System.Net.Mime.MediaTypeNames;
using TMPro;

public class MainMenu_Script : MonoBehaviour
{
    public TMP_Text TexteScore;
    private float tempsJeuSaved = 0;
    // Start is called before the first frame update
    void Start()
    {
        tempsJeuSaved = partage.tempsJeu;
        PlayerPrefs.SetFloat("tempsJeuSaved", tempsJeuSaved);
        if (TexteScore != null)
            TexteScore.text = "Temps : " + tempsJeuSaved.ToString("0.0") + " secondes!";
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Play()
    {
        SceneManager.LoadScene(2);
        partage.tempsJeu = 0;
    }

    public void CloseGame()
    {
        UnityEngine.Application.Quit();
    }

}
