using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class partage : MonoBehaviour
{

    public static int ActualLevel = 1;
    public static float tempsJeu = 0;
    public static AudioSource hitDamageSound;
    public static Player_Script player;
    public static Slime SlimeToucher;
    public static MurSpike mur;
    public static pools1 bulletPool;

    public static float ClampFloat(float value,float min, float max)
    {
        if(value < min) return min;
        if(value > max) return max;
        return value;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
