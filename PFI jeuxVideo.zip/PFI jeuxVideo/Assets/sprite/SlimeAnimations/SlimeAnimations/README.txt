[ENG]
Hello everyone! I'm Reff. You can find more projects from me on twitter @Reff_SQ

This is a very small free asset pack. You'll find a bunch of animations for a Slime i did long ago, this is pretty much just to test the waters of Itch.io

ANIMATIONS INCLUDED (12):
� Red Slime Jump Animation
� Red Slime Idle Animation
� Red Slime Attack Animation
� Red Slime Death Animation

� Blue Slime Jump Animation
� Blue Slime Idle Animation
� Blue Slime Attack Animation
� Red Slime Death Animation

� Green Slime Jump Animation
� Green Slime Idle Animation
� Green Slime Attack Animation
� Green Slime Death Animation

All animations are saved in gif and png!

NOTE: Ignore the "itchio" folder. These are edits of the assets used for the presentation on Itch.io
You may use the assets inside of it, but they are not properly crafted for games.

LICENCE: 
This asset pack can be used in both free and commercial projects. You can modify it to suit your own needs. Credit is unnecessary, but highly appreciated (@Reff_SQ).  
You may not redistribute, resell or take your own credit for this Asset Pack, a fraction of it, or a slightly modified version.