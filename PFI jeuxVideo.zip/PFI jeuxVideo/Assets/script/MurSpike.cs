using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MurSpike : MonoBehaviour
{
    public float speed = 1;
    // Update is called once per frame
    void Awake()
    {
        partage.mur = this;
    }
    void Update()
    {
        Vector3 v = new(speed*Time.deltaTime,0,0);
        this.transform.Translate(v);
    }
}
