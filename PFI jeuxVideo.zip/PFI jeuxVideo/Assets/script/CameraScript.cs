using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour
{
    public GameObject Follow;
    public Vector3 offset;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Follow != null)
            transform.position = new Vector3(Follow.transform.position.x + offset.x, Follow.transform.position.y + offset.y, offset.z);
    }

    public void setFollowNull()
    {
        Follow = null;
    }
}
