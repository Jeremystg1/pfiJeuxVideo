using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlimeVolant : MonoBehaviour
{
    // Start is called before the first frame update
    //y = amplitude *Mathf.sin(valeurRadians)
    private float amplitude = 8;
    private float radStepPerFrame = .005f;
    private Space space = Space.World;

    Vector3 oriPos;
    private int frameCount = 0;
    void Start() { oriPos = transform.position; }

    // Update is called once per frame
    void Update()
    {
        frameCount++;
        float y = amplitude * Mathf.Sin(radStepPerFrame * frameCount) * Time.deltaTime;

        transform.Translate(new Vector3(0, y, 0), space);
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Player")
            partage.player.slimeVolantTouch�(this);
    }
}
