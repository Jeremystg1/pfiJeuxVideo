using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using System;
//source song jeu https://www.youtube.com/watch?v=tQR6jyfK6Ps&list=PLdsGes2mFh92eHpOZVJQgoubb6rF0CcvU&index=3
[RequireComponent(typeof(pools1))]
public class Player_Script : MonoBehaviour
{
    private float _nbPv = 3;
    private bool d�j�D�c�d� = false;
    public float nbPV { get { return _nbPv; } set {
            if(_nbPv != 0)
                //if(partage.hitDamageSound != null)
                try { partage.hitDamageSound.Play(); } catch(Exception e) { }
                    
            else {
                if (!d�j�D�c�d�)
                {
                    try { partage.hitDamageSound.Play(); } catch (Exception e) { }
                    d�j�D�c�d� = true;
                }
            }
            _nbPv = value; 
        } }
    private float speed = 40;
    public const float GRAVITYPOWER = 3f; //.1f
    private Animateur animateur;
    private Rigidbody2D foxRB;
    private SpriteRenderer foxSR;
    private pools1 poolsBullet;
    public TMP_Text pvValueText;
    public int Orientation;
    public bool dying = false;
    public bool inputDisable = false;
    public Sprite doorOpenSprite;
    public GameObject FinishPoint = null;
    private bool TakingDamage = false;
    private float elapsedTime = 0;
    private float TimeOutDamage = 0.5f;
    [SerializeField] private TMP_Text TempsLabel;
    public bool isGroundedx = false;
    public CharacterController2D controller;
    float horizontalMove = 0f;
    private AudioSource jumpAudio;
    bool jump = false;
    bool crouch = false;
    // Start is called before the first frame update
    void Start()
    {
        //partage.tempsJeu = 0;
        jumpAudio = this.GetComponent<AudioSource>();
        partage.bulletPool = this.poolsBullet;
    }
    void Awake() {this.foxSR = GetComponentInChildren<SpriteRenderer>(); this.poolsBullet = GetComponent<pools1>(); foxRB = this.gameObject.GetComponent<Rigidbody2D>(); partage.player = this; animateur = new(this.gameObject);}
    //https://www.youtube.com/watch?v=dwcT-Dch0bA
    //https://raw.githubusercontent.com/Brackeys/2D-Character-Controller/master/CharacterController2D.cs
    void Update()
    {
        
        // (Vector2,bool) inputVb = getInputVector();
        // bool isJumping = inputVb.Item2;
        // print("isjumping: " + isJumping);
        // Vector2 inputV = inputVb.Item1;
        // float forceY = 0;
        //// foxRB.velocity = new();
        // //foxRB.AddForce(new Vector2(0, -GRAVITYPOWER));
        // if (isJumping && IsGrounded())
        // {
        //     forceY = jumpForce * Time.deltaTime;
        //     foxRB.AddForce(new Vector2(0, forceY));
        // }

        // //if (!IsGrounded())
        // //animateur.playAnim("Jump");
        // gravit�PasTouch = 0; //= partage.ClampFloat(-GRAVITYPOWER*Time.deltaTime, -GRAVITYMAX, GRAVITYMAX*100);
        // Vector3 v = new(inputV.x*Time.deltaTime,
        //      gravit�PasTouch, 0);
        // //print(inputV);
        // //gravit�PasTouch += -GRAVITYPOWER*Time.deltaTime;
        // Quaternion q = new();
        // if (inputV.x > 0)
        //     q = new(0, 0, 0,0);
        // if (inputV.x < 0)
        //     q = new(0, 180, 0,0);
        // if(inputV.x == 0 && IsGrounded())
        // {
        //     animateur.playAnim("Idle");
        // } else if(!IsGrounded())
        //     animateur.playAnim("Jump");
        // else animateur.playAnim("run");

        // spriteFox.transform.rotation = q;
        // ancienPosition = this.transform.position;
        // this.transform.Translate(v);

        if (!inputDisable)
        {
            partage.tempsJeu += Time.deltaTime;
            TempsLabel.text = "Temps: " + partage.tempsJeu.ToString("0.0");
            //utilisation du charactercontroller2D de la chaine youutbe Brackeys https://www.youtube.com/watch?v=dwcT-Dch0bA
            horizontalMove = Input.GetAxisRaw("Horizontal") * speed;

            //print(horizontalMove);
            if (Input.GetKeyDown(KeyCode.W))
            {
                jump = true;
                jumpAudio.volume = .5f;
                jumpAudio.Play();
            }

            if (Input.GetKeyDown(KeyCode.Space))
            {
                Shoot();
            }

            controller.Move(horizontalMove * Time.fixedDeltaTime, crouch, jump);
            if (!this.isGroundedx && !dying)
                animateur.playAnim("Jump");
            if (horizontalMove != 0 && this.isGroundedx && !dying)
                animateur.playAnim("run");
            else if (this.isGroundedx && !dying)
                animateur.playAnim("Idle");
            else if (dying)
            {
                animateur.playAnim("Die");
            }

            jump = false;

            if (TakingDamage)
            {
                elapsedTime += Time.deltaTime;
                if (elapsedTime >= TimeOutDamage)
                {
                    TakingDamage = false;
                    elapsedTime = 0;
                    foxSR.color = Color.white;
                }
            }
        }
        if (FinishPoint != null) 
        {
            if (gameObject.transform.position.x >= FinishPoint.transform.position.x)
            {
                FinishPoint.GetComponentInChildren<SpriteRenderer>().sprite = doorOpenSprite;
                StartCoroutine(Finish(null));
            }
        }

        if (nbPV <= 0)
        {
            nbPV = 0;
            dying = true;
            StartCoroutine(die());
        }

    }
    private void refreshHealthUI()
    {
        pvValueText.text = nbPV.ToString();
    }
    public void slimeTouch�(Slime slime)
    {
        foxSR.color = Color.red;
        TakingDamage = true;
        nbPV--;
        refreshHealthUI();
        Destroy(slime.gameObject);
    }
    public void slimeVolantTouch�(SlimeVolant slimeVolant)
    {
        foxSR.color = Color.red;
        TakingDamage = true;
        nbPV--;
        refreshHealthUI();
        Destroy(slimeVolant.gameObject);
    }

    public void Shoot()
    {
        var bullet = poolsBullet.Take();
        bullet.transform.position = new Vector3(gameObject.transform.position.x, gameObject.transform.position.y - .2f, gameObject.transform.position.z);
        bullet.GetComponent<BulletScript>().Orientation = this.Orientation;
        bullet.SetActive(true);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!inputDisable)
        {
            if (collision.gameObject.tag == "killingZone" || collision.gameObject.tag == "Mur")
            {
                nbPV = 0;
                inputDisable = true;
                refreshHealthUI();
                dying = true;
                StartCoroutine(die());
            }
        }

        if (!TakingDamage && !inputDisable)
        {
            if (collision.gameObject.tag == "spike")
            {
                nbPV--;
                refreshHealthUI();
            }

            if (collision.tag == "EndZone")
            {
                inputDisable = true;
                FinishPoint = collision.gameObject;
                StartCoroutine(Finish(collision.gameObject));
            }
               
            if(collision.tag != "bullet" && collision.tag != "EndZone")
            {
                TakingDamage = true;
                foxSR.color = Color.red;
            }
            

        }
        
    }

    IEnumerator die()
    {
        for(int i = 0; i <3; i++)
        {
            foxRB.bodyType = RigidbodyType2D.Kinematic;
            foxRB.simulated = false;
            controller.enabled = false;
            Camera.main.GetComponent<CameraScript>().setFollowNull();
            animateur.playAnim("Die");
            yield return new WaitForSeconds(.008f);
            foxRB.bodyType = RigidbodyType2D.Dynamic;
            foxRB.gravityScale = .1f;

            foxRB.simulated = true;
            controller.enabled = true;
        }


        
        yield return new WaitForSeconds(1);
       // StopCoroutine(die());
        SceneManager.LoadScene(1);
        //dying = false;

    }

    IEnumerator Finish(GameObject finishPoint)
    {
        if(finishPoint == null)
        {

            if (partage.ActualLevel == 1)
            {
                yield return new WaitForSeconds(1);
                SceneManager.LoadScene(3);
            }
        }
        else
        {
            for (; gameObject.transform.position.x <= finishPoint.transform.position.x;)
            {
                animateur.playAnim("run");
                //Debug.Log("avancer");
                gameObject.transform.position = gameObject.transform.position + (Vector3.right*(speed/10) * Time.deltaTime);
                yield return null;
            }
        }
    }

}
public class Animateur
{
    GameObject plr;
    Animator animator;
    public Animateur(GameObject plr)
    {
        this.plr = plr;
        this.animator = plr.gameObject.GetComponentInChildren<Animator>();
    }

    public void playAnim(string str)
    {
        animator.Play(str, 0);
    }
    public void playAnimOnce(string str)
    {
        this.playAnim(str);
    }
}