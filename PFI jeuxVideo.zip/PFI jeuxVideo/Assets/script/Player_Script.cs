using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(pools1))]
public class Player_Script : MonoBehaviour
{
    public float nbPV = 3;
    private float speed = 40;
    private float jumpForce = 30; //5
    public const float GRAVITYPOWER = 3f; //.1f
    private const float GRAVITYMAX = .2f;
    private Animateur animateur;
    private GameObject spriteFox;
    private Rigidbody2D foxRB;
    private pools1 poolsBullet;
    public TMP_Text pvValueText;
    public int Orientation;
    public bool dying = false;

    public bool isGroundedx = false;
    public CharacterController2D controller;
    float horizontalMove = 0f;
    bool jump = false;
    bool crouch = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }
    void Awake() { this.poolsBullet = GetComponent<pools1>(); foxRB = this.gameObject.GetComponent<Rigidbody2D>(); partage.player = this; animateur = new(this.gameObject); spriteFox = GameObject.Find("SpriteFox"); }
    (Vector2,bool) getInputVector()
    {
        Vector2 v = new(Input.GetAxis("Horizontal")*speed, partage.ClampFloat(Input.GetAxis("Vertical"),-GRAVITYMAX,GRAVITYMAX));
        bool isJumping = false;
        if(v.y > 0)
            isJumping = true;
        v = new Vector2(v.x, 0);
        
        return (v,isJumping);
    }
    // Update is called once per frame
    private Vector3 ancienPosition = new();
    bool IsGrounded()
    { //https://answers.unity.com/questions/196381/how-do-i-check-if-my-rigidbody-player-is-grounded.html
      //var pos2d = new Vector2(this.transform.position.x, this.transform.position.y);

        //RaycastHit2D r = Physics2D.Raycast(pos2d + new Vector2(0, 4.01f), -Vector2.up);
        //print(-Vector2.up);
        //print(r.collider);
        //print(r.rigidbody);

        //return r.collider != null;
        bool e = ancienPosition.y == this.transform.position.y;
        print(e);
        return e;
    }
private float gravit�PasTouch = 0;

    //https://www.youtube.com/watch?v=dwcT-Dch0bA
    //https://raw.githubusercontent.com/Brackeys/2D-Character-Controller/master/CharacterController2D.cs
    void Update()
    {
        // (Vector2,bool) inputVb = getInputVector();
        // bool isJumping = inputVb.Item2;
        // print("isjumping: " + isJumping);
        // Vector2 inputV = inputVb.Item1;
        // float forceY = 0;
        //// foxRB.velocity = new();
        // //foxRB.AddForce(new Vector2(0, -GRAVITYPOWER));
        // if (isJumping && IsGrounded())
        // {
        //     forceY = jumpForce * Time.deltaTime;
        //     foxRB.AddForce(new Vector2(0, forceY));
        // }

        // //if (!IsGrounded())
        // //animateur.playAnim("Jump");
        // gravit�PasTouch = 0; //= partage.ClampFloat(-GRAVITYPOWER*Time.deltaTime, -GRAVITYMAX, GRAVITYMAX*100);
        // Vector3 v = new(inputV.x*Time.deltaTime,
        //      gravit�PasTouch, 0);
        // //print(inputV);
        // //gravit�PasTouch += -GRAVITYPOWER*Time.deltaTime;
        // Quaternion q = new();
        // if (inputV.x > 0)
        //     q = new(0, 0, 0,0);
        // if (inputV.x < 0)
        //     q = new(0, 180, 0,0);
        // if(inputV.x == 0 && IsGrounded())
        // {
        //     animateur.playAnim("Idle");
        // } else if(!IsGrounded())
        //     animateur.playAnim("Jump");
        // else animateur.playAnim("run");

        // spriteFox.transform.rotation = q;
        // ancienPosition = this.transform.position;
        // this.transform.Translate(v);

        //utilisation du charactercontroller2D de la chaine youutbe Brackeys https://www.youtube.com/watch?v=dwcT-Dch0bA
        horizontalMove = Input.GetAxisRaw("Horizontal") * speed;
        
        //print(horizontalMove);
        if (Input.GetKeyDown(KeyCode.W))
        {
            jump = true;
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            Shoot();
        }
            
        controller.Move(horizontalMove * Time.fixedDeltaTime, crouch, jump);
        if(!this.isGroundedx && !dying)
          animateur.playAnim("Jump");
        if (horizontalMove != 0 && this.isGroundedx && !dying)
            animateur.playAnim("run");
        else if(this.isGroundedx && !dying)
                animateur.playAnim("Idle");
        else if (dying)
        {
            animateur.playAnim("Die");
        }
            
        jump = false;


        
    }
    private void refreshHealthUI()
    {
        pvValueText.text = nbPV.ToString();
    }
    public void slimeTouch�(Slime slime)
    {
        nbPV--;
        refreshHealthUI();
        Destroy(slime.gameObject);
    }
    public void slimeVolantTouch�(SlimeVolant slimeVolant)
    {
        nbPV--;
        refreshHealthUI();
        Destroy(slimeVolant.gameObject);
    }

    public void Shoot()
    {
        var bullet = poolsBullet.Take();
        bullet.transform.position = new Vector3(gameObject.transform.position.x, gameObject.transform.position.y - .2f, gameObject.transform.position.z);
        bullet.GetComponent<BulletScript>().Orientation = this.Orientation;
        bullet.SetActive(true);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "spike")
        {
            nbPV--;
            refreshHealthUI();
        }
        else if (collision.gameObject.tag == "killingZone")
        {
            nbPV = 0;
            refreshHealthUI();
            dying = true;
            
            StartCoroutine(die());
        }
    }

    IEnumerator die()
    {
        for(int i = 0; i <3; i++)
        {
            foxRB.bodyType = RigidbodyType2D.Kinematic;
            foxRB.simulated = false;
            controller.enabled = false;
            Camera.main.GetComponent<CameraScript>().setFollowNull();
            yield return new WaitForSeconds(.008f);
            foxRB.bodyType = RigidbodyType2D.Dynamic;
            foxRB.simulated = true;
            controller.enabled = true;
        }


        
        yield return new WaitForSeconds(1);
       // StopCoroutine(die());
        SceneManager.LoadScene(1);
        //dying = false;

    }
}
public class Animateur
{
    GameObject plr;
    Animator animator;
    public Animateur(GameObject plr)
    {
        this.plr = plr;
        this.animator = plr.gameObject.GetComponentInChildren<Animator>();
    }

    public void playAnim(string str)
    {
        animator.Play(str, 0);
    }
    public void playAnimOnce(string str)
    {
        this.playAnim(str);
    }
}
