using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletScript : MonoBehaviour
{
    public int Orientation = 1;
    private float Speed = 2f;
    [SerializeField]public GameObject spritefeu;
    // Start is called before the first frame update
    void Start()
    {
        if (Orientation == 0)
            Orientation = 1;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 v3 = new(Speed*Time.deltaTime * Orientation, 0);
        transform.Translate(v3);
        spritefeu.transform.Rotate(new Vector3(0, 0, 1));
    }
}
