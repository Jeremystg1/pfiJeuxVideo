using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Slime : MonoBehaviour
{
    public float pv = 3;
    public float speed = 5;
    Rigidbody2D m_Rigidbody2D;
    private Animateur animateur;
    private float jumpForce = 400;
    float elapsedTime = 0;
    float delay = 3;
    // Start is called before the first frame update
    void Start()
    {
        m_Rigidbody2D = GetComponent<Rigidbody2D>();
    }
    void Awake() { animateur = new Animateur(this.gameObject); }
    // Update is called once per frame
    void Update()
    {
        elapsedTime += Time.deltaTime;
        if(elapsedTime >= delay)
        {
            m_Rigidbody2D.AddForce(new Vector2(0f, jumpForce));
            elapsedTime = 0;
            animateur.playAnimOnce("SlimeJump");
        }
        
    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
            partage.player.slimeTouch�(this);
    }
}
